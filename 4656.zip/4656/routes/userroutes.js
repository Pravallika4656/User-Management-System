const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/usermodel'); 
const path = require('path'); 

const router = express.Router();

router.get("/", async (req, res) => {
    try {
        const users = await User.find(); 
        res.json(users);
    } catch (error) {
        res.status(500).send("Error fetching users");
    }
});

router.post("/register", async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).send("All fields are required");
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send("User already exists");
        }

        const newUser = new User({ name, email, password });
        await newUser.save(); 
        res.redirect('/login');
    } catch (error) {
        res.status(500).send("Error registering user");
    }
});
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        const existingUser = await User.findOne({ email, password });
        if (existingUser) {
            res.redirect("/dashboard"); 
        } else {
            res.status(401).send("Invalid email or password");
        }
    } catch (error) {
        res.status(500).send("Error during login");
    }
});

router.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/registration.html')); 
});

router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/login.html')); 
});

router.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/dashboard.html')); 
});

module.exports = router;
