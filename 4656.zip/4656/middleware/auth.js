// middleware/auth.js

module.exports.isAuthenticated = (req, res, next) => {
    if (req.session && req.session.userId) {
        return next(); // User is logged in, proceed to next middleware/route
    } else {
        return res.status(401).send("Unauthorized: Please login");
    }
};
